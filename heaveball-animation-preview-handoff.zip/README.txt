Heaveball animation preview

This preview contains the 49 new and revised clips from the latest animation
update: missed tackles, diving catches and tips, gamble attempts, drops,
sideline saves, and ball bounces on turf, grass, and clay.

Open the preview
1. Extract the ZIP.
2. Open heaveball-latest-animation-preview.html in a browser with WebGL.
   The player model and all other preview assets are embedded in the HTML.
   The preview works offline.
3. Use Previous and Next to step through clips, or choose a category to
   narrow the playlist. Drag on the field to rotate the camera.

Publish to the GPT test site
Include heaveball-latest-animation-preview.html in the Matchroom test site's
static build output alongside the existing dist/index.html. Publish the build
from an account with editor access to the Heaveball Matchroom Site.

Once published, open the preview at
https://heaveball-matchroom.hardyburl128.chatgpt.site/heaveball-latest-animation-preview.html
